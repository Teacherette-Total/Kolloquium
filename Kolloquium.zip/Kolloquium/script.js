const modal = document.getElementById("modal");
const modalText = document.getElementById("modal-text");

const content = {
  ds: `<ul><li>Integration von KI & Blended Learning</li><li>KI für Evaluation & Entwicklung</li></ul>`,
  ki: `<ul><li>KI-Kompetenz & 6C</li><li>Implementationskonzept schulübergreifend</li></ul>`
  // Weitere Inhalte ergänzen
};

function openModal(key) {
  modalText.innerHTML = content[key] || "<p>Inhalt fehlt</p>";
  modal.style.display = "block";
}

function closeModal() {
  modal.style.display = "none";
}
