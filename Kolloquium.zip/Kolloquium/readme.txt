# Profilübersicht Kolloquium – Digitale Schulentwicklung

Dieses Projekt enthält eine HTML-Seite zur interaktiven Darstellung deines Kolloquiumsprofils mit Fokus auf KI, Blended Learning, Change Management und Agilität.

## 🔧 Nutzung lokal
1. Ordner erstellen (z. B. `kolloquium-profil`)
2. Dateien speichern (index.html, style.css, script.js)
3. `index.html` im Browser öffnen

## 🚀 Veröffentlichen mit GitHub Pages
1. Repository auf GitHub anlegen
2. Dateien hochladen (index.html, style.css, script.js)
3. Unter **Settings > Pages**:
   - Source: `main`
   - Ordner: `/ (root)`
4. URL aufrufen: `https://<username>.github.io/<repo>/`

📄 Erstellt von Revisions-Coach ✨
